<?php  $this->load->view("web/includes/header_styles"); ?>
    <!--header area end-->
    

    <!--slider area start-->

    <section class="slider_section slider_s_three">

        <div class="slider_area owl-carousel">
            <?php 
                //echo "<pre>"; print_r($banners); die;
            foreach($banners as $bnr){ ?>
            <?php if($bnr['type']=='products'){?>
                                    <a href="<?php echo base_url(); ?>web/product_view/<?php echo $bnr['product_details']['seo_url']; ?>">
                                <?php }else{ ?> 
                                    <a href="<?php echo base_url(); ?>web/store/<?php echo $bnr['product_details']['seo_url']; ?>/shop">
                                <?php }?>
              <!-- <div class="single_slider d-flex align-items-center" data-bgimg="<?php echo $bnr['image']; ?>"> -->
              <div class="single_slider">

                <img src="<?php echo $bnr['image']; ?>" alt="" class="home-slider-img" width="100%">

               

            </div></a>
        <?php } ?>

        </div>

    </section>

    <!--slider area end-->

    <div id="show_errormsg1"></div>
    

     <!--categories product area start-->

    <div class="categories_product_area mb-30">

        <div class="container">

        <div class="row">

            <div class="col-lg-12">
                
                    <div class="section_title product_shop_title">

                       <h2>Categories</h2> <a href="<?php echo base_url() ?>web/viewAllCategories" class="btn btn-sm pink-btn float-right"> View All </a>

                    </div>

                

            </div>


        </div> 

            <div class="row">

               <div class="product_carousel product_column4 owl-carousel">
                    <?php foreach($categories as $category){ ?>
                   <div class="col-lg-3">

                        <article class="single_categories">

                            <figure>

                                <div class="categories_thumb">

                                    <a href="<?php echo base_url(); ?>web/store_categories/<?php echo $category['seo_url']; ?>"><img src="<?php echo $category['image']; ?>" alt=""></a>

                                </div>

                                <figcaption class="categories_content">

                                    <h4 class="product_name"><a href="<?php echo base_url(); ?>web/store_categories/<?php echo $category['seo_url']; ?>"><?php echo $category['title']; ?></a></h4>

                                </figcaption>

                            </figure>

                        </article>

                   </div>

               <?php } ?>

           
               </div>

           </div>   

        </div> 

    </div>

    <!--categories product area end-->

              

    <!--product area start-->
    <div id="top_fav_msg" style="text-align: center; padding: 10px;"></div>

    <div class="product_area  mb-50">

        <div class="container">

            <div class="row">

                <div class="col-12">

                    <div class="section_title product_shop_title">

                       <h2>Top Deals</h2>
                       <a href="<?php echo base_url() ?>web/viewallProducts/topdeals" class="btn btn-sm pink-btn float-right"> View All </a>
                    </div>

                </div>

            </div> 

            <div class="row" >

              <!-- <div class="toast" id="show_errormsg_topdeal" style="color: green; text-align: center;">
                            <div class="toast-header">
                              <strong class="mr-auto"><i class="fa fa-grav"></i> We miss you!</strong>
                                <small>11 mins ago</small> 
                                <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
                            </div>
                            <div class="toast-body">
                                Product Added to cart
                            </div>
                        </div> -->

               <div class="product_carousel product_column5 owl-carousel" id="topdeals">

                    <?php foreach($topdeals as $deals){?>

                  <div class="col-lg-3">
                        <article class="single_product">
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><img src="<?php echo $deals['image']; ?>" alt=""></a>
                                        <a class="secondary_img" href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><img src="<?php echo $deals['image']; ?>" alt=""></a>
                                        <div class="label_product">
                                            <span class="label_sale">Sale</span>
                                        </div>
                                        <div class="wishlist">
                                            <a title="Add to Wishlist" onclick="addremoveTOpDealsFavorite(<?php echo $deals['id']; ?>)"><span id="favoritecls_<?php echo $deals['id']; ?>" class="<?php if($deals['whishlist_status']==true){ echo 'fas'; }else{ echo 'fal'; } ?> fa-heart"></span></a>
                                        </div>
                                        
                                    </div>
                                    <figcaption class="product_content">
                                        <div class="product_content_inner">
                                            <h4 class="product_name"><a href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><?php echo $deals['name']; ?></a></h4>

                                            <p class="shop-name"><?php echo $deals['shop']; ?></p>
                                            <div class="price_box"> 
                                                <span class="current_price"><i class="fal fa-rupee-sign"></i> <?php echo $deals['saleprice']; ?></span>
                                            </div>
                                        </div>
                                        <div class="add_to_cart">
                                            <a onclick="addtocart(<?php echo $deals['variant_id']; ?>,<?php echo $deals['shop_id']; ?>,'<?php echo $deals['saleprice']; ?>',1)"><i class="fal fa-shopping-cart fa-lg"></i> Add to cart</a>
                                        </div>
                                    </figcaption>
                                </figure>
                        </article>
                   </div>
               <?php } ?>

               </div>

           </div>   

        </div> 

    </div>

    <!--product area end-->


     <!--trending offers start-->

    <div class="product_area  mb-50">

        <div class="container">

            <div class="row">

                <div class="col-12">

                    <div class="section_title product_shop_title">

                       <h2>Trending offers</h2>
                       <a href="<?php echo base_url() ?>web/viewallProducts/trending" class="btn btn-sm pink-btn float-right"> View All </a>
                    </div>

                </div>

            </div> 

           

            

            <!-- <div class="toast" id="show_errormsg_trending" style="color: green; text-align: center;"> -->
                <!-- <div class="toast" id="show_errormsg_trending" style="color: green; text-align: center; margin:0px auto;">
                    <div class="toast-header"> 
                        <button type="button" class="ml-2 mb-1 close" data-dismiss="toast">&times;</button>
                    </div>
                     <div class="toast-body">
                        Product Added to cart
                    </div>
                </div> -->
            <div class="row" id="trending_now">
                        
               <div class="product_carousel product_column5 owl-carousel" >
                    
                    <?php foreach($trending as $deals){ ?>
                  <div class="col-lg-3" >
                        <article class="single_product">
                              <span id="favorites<?php echo $deals['id']; ?>"></span>
                                <figure>
                                    <div class="product_thumb">
                                        <a class="primary_img" href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><img src="<?php echo $deals['image']; ?>" alt=""></a>
                                        <a class="secondary_img" href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><img src="<?php echo $deals['image']; ?>" alt=""></a>
                                        <div class="label_product">
                                            <span class="label_sale">Sale</span>
                                        </div>
                                        <div class="wishlist">
                                            <a title="Add to Wishlist" onclick="addFavorite_NEW(<?php echo $deals['id']; ?>)"><span id="rendingfavorites_<?php echo $deals['id']; ?>" class="<?php if($deals['whishlist_status']==true){ echo 'fas'; }else{ echo 'fal'; } ?> fa-heart"></span></a>
                                        </div>
                                        
                                    </div>
                                    <figcaption class="product_content">
                                        <div class="product_content_inner">
                                            <h4 class="product_name"><a href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><?php echo $deals['name']; ?></a></h4>
                                            <p class="shop-name"><?php echo $deals['shop']; ?></p>
                                            <div class="price_box"> 
                                                <span class="current_price"><i class="fal fa-rupee-sign"></i> <?php echo $deals['saleprice']; ?></span>


                                            </div>
                                        </div>
                                        <div class="add_to_cart">
                                            <a onclick="addtocart(<?php echo $deals['variant_id']; ?>,<?php echo $deals['shop_id']; ?>,'<?php echo $deals['saleprice']; ?>',1)" ><i class="fal fa-shopping-cart fa-lg"></i> Add to cart</a>
                                        </div>
                                    </figcaption>
                                </figure>
                        </article>
                   </div>
               <?php } ?>

               </div>

           </div>   

        </div> 

    </div>

    <!--close trending offers-->

      <script type="text/javascript">
  function addremoveTOpDealsFavorite(pid)
  {
    var user_id = '<?php echo $_SESSION['userdata']['user_id']; ?>';
      if(user_id=='')
      {
        $('#loginModal').modal('show');
        return false;
      }
      else
      {
            $.ajax({
              url:"<?php echo base_url(); ?>web/add_remove_topdeal_whishList",
              method:"POST",
              data:{pid:pid},
              success:function(data)
              {

                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
              //location.reload();
             // $("#topdeals").load(location.href + " #topdeals");

              // $('html, body').animate({
              //           scrollTop: $('#show_errormsg1').offset().top - 100 //#DIV_ID is an example. Use the id of your destination on the page
              //       }, 'slow');
               
                  if(res[1]=='remove')
                  {
                    
                     /* $("#topdeals").load(location.href + " #topdeals");
                      $('#top_fav_msg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Removed from the Favourites</span>');
                      $('#top_fav_msg').focus();
                      location.reload();
                        return false;*/
                        $("#favoritecls_"+pid).removeClass("fas");
                         $("#favoritecls_"+pid).addClass("fal");

                  }
                  else if(res[1]=='add')
                  {
                    $("#favoritecls_"+pid).removeClass("fal");
                     $("#favoritecls_"+pid).addClass("fas");
                      /*$('#top_fav_msg').html('<span class="error" style="color:green;font-size: 16px;margin-left: 18px; width:100%">Added to Favourites</span>');
                      $('#top_fav_msg').focus();

                       location.reload();
                        return false;*/
                  }
                      
              
              
              }
             });
      }
  }

  function addFavorite_NEW(pid)
  {
    var user_id = '<?php echo $_SESSION['userdata']['user_id']; ?>';
      if(user_id=='')
      {
        $('#loginModal').modal('show');
        return false;
      }
      else
      {
            $.ajax({
              url:"<?php echo base_url(); ?>web/add_most_viewed_removewhishList",
              method:"POST",
              data:{pid:pid},
              success:function(data)
              {

                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
              //location.reload();
              //$("#trending_now").load(location.href + " #trending_now");
              /*$('html, body').animate({
                        scrollTop: $('#show_errormsg1').offset().top - 100 //#DIV_ID is an example. Use the id of your destination on the page
                    }, 'slow');*/
                   if(res[1]=='remove')
                  {
                    
                      /*$("#topdeals").load(location.href + " #topdeals");
                      $('#top_fav_msg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Removed from the Favourites</span>');
                      $('#top_fav_msg').focus();
                      location.reload();
                        return false;*/
                        $("#rendingfavorites_"+pid).removeClass("fas");
                         $("#rendingfavorites_"+pid).addClass("fal");
                         
                  }
                  else if(res[1]=='add')
                  {
                     
                      /*$('#top_fav_msg').html('<span class="error" style="color:green;font-size: 16px;margin-left: 18px; width:100%">Added to Favourites</span>');
                      $('#top_fav_msg').focus();

                       location.reload();
                        return false;*/

                         
                         $("#rendingfavorites_"+pid).removeClass("fal");
                         $("#rendingfavorites_"+pid).addClass("fas");
                  }
                        
              
              
              }
             });
      }
  }
      </script> 

     <!--banner area start-->

    <div class="banner_area banner_area3 mb-50">

        <div class="container">

            <div class="row">
                <?php foreach($bannerads as $banner){ ?>
                <div class="col-lg-4 col-md-4 col-sm-6">

                    <div class="single_banner">

                        <div class="banner_thumb">

                            <a <?php if($banner['type']=='shops'){?> href="<?php echo base_url(); ?>web/store/<?php echo $banner['product_details']['seo_url']; ?>/shop" <?php }else {?>href="<?php echo base_url(); ?>web/product_view/<?php echo $banner['product_details']['seo_url']; ?>"<?php } ?>><img src="<?php echo $banner['image']; ?>" alt=""></a>

                        </div>

                    </div>

                </div>

              <?php } ?>

                <!-- <div class="col-lg-4 col-md-4 col-sm-6">

                    <div class="single_banner">

                        <div class="banner_thumb">

                            <a href="#"><img src="<?php echo base_url();?>web_assets/img/add-2.jpg" alt=""></a>

                        </div> 

                    </div>

                </div>

                <div class="col-lg-4 col-md-4 col-sm-6">

                    <div class="single_banner col3">

                        <div class="banner_thumb">

                            <a href="#"><img src="<?php echo base_url();?>web_assets/img/add-3.jpg" alt=""></a>

                        </div> 

                    </div>

                </div> -->

            </div>

        </div>

    </div>

    <!--banner area end-->

    

    <!--product area start-->

    <section class="blog_section">

        <div class="container">

            <div class="row">

                <div class="col-12">

                    <div class="section_title product_shop_title">

                       <h2>Nearest Stores</h2>
                       <a href="<?php echo base_url() ?>web/viewallshops" class="btn btn-sm pink-btn float-right"> View All </a>
                    </div>

                    

                </div>

            </div>

            <div class="row">

                <div class="blog_carousel blog_column3 owl-carousel storesnearbox pt-2">

                    <?php foreach($shops as $shop){ ?>

                    <div class="col-lg-4">

                   <div class="card shadow-sm mb-3">

                       <div class="img-box">

                         <a href="<?php echo base_url(); ?>web/store/<?php echo $shop['seo_url']; ?>/shop"><img src="<?php echo $shop['image']; ?>" alt="" class="card-img-top"></a>

                         <h5><i class="fal fa-badge-percent"></i> <?php echo $shop['deal_products']; ?> DEALS</h5>

                       </div>

                       <div class="card-body">

                         <div class="row">

                           <div class="col-lg-12">

                             <h4><a href="<?php echo base_url(); ?>web/store/<?php echo $shop['seo_url']; ?>/shop"><?php echo $shop['shop_name']; ?></a></h4>

                             <p><?php echo substr($shop['description'],0,40)."..."; ?></p>

                             <p><i class="fal fa-map"></i> <?php echo $shop['address']; ?></p>

                           </div>

                         </div>

                       </div>

                       <div class="card-footer">

                        <div class="row">

                           <div class="col-lg-6"><p><small><i class="fal fa-map-marker-alt"></i> <?php echo $shop['distance']; ?>Km</small></p></div>

                           <div class="col-lg-6 text-right"><a href="<?php echo base_url(); ?>web/store/<?php echo $shop['seo_url']; ?>/shop"><p class="pinkcol"><small><?php echo $shop['product_total']; ?> Products</small></p></a></div>

                        </div>

                      </div>

                   </div>

                    </div>
                   <?php } ?>


                   

                </div>

            </div>

        </div>
        <?php
    $session_id = $_SESSION['session_data']['session_id'];
    $user_id= $_SESSION['userdata']['user_id'];
    $cart_qry = $this->db->query("select * from cart where session_id='".$session_id."' and user_id='".$user_id."'");
       $cart_count = $cart_qry->num_rows();    
 ?>

    </section>
   <!--discount banner area start-->

    <!-- <div class="discount_banner_area">

        <div class="container-fluid p-0">

            <div class="banner_thumb">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <a <?php if($lastbannerads['type']=='shops'){?> href="<?php echo base_url(); ?>web/store/<?php echo $lastbannerads['product_details']['seo_url']; ?>" <?php }else {?>href="<?php echo base_url(); ?>web/product_view/<?php echo $lastbannerads['product_details']['seo_url']; ?>"<?php } ?>><img src="<?php echo $lastbannerads['image']; ?>" alt="" class="img-fluid"></a>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="banner_text3">

                    <h3><?php echo $lastbannerads['title']; ?></h3>

                    <h2>up TO 40% off</h2>

                    <p>An exclusive selection of this season’s trends. <span>Exclusively online!</span></p>

                    <a <?php if($lastbannerads['type']=='shops'){?> href="<?php echo base_url(); ?>web/store/<?php echo $lastbannerads['product_details']['seo_url']; ?>" <?php }else {?>href="<?php echo base_url(); ?>web/product_view/<?php echo $lastbannerads['product_details']['seo_url']; ?>"<?php } ?>>shop now</a>

                </div>
                    </div>
                </div>
                

                

            </div>

        </div>

    </div> -->






<?php
    $session_id = $_SESSION['session_data']['session_id'];
    $user_id= $_SESSION['userdata']['user_id'];
    $cart_qry = $this->db->query("select * from cart where session_id='".$session_id."' and user_id='".$user_id."'");
       $cart_count = $cart_qry->num_rows();    
 ?>



   
    <!--discount banner area end-->





  <?php  $this->load->view("web/includes/footer"); ?>
