<ul class="step d-flex flex-nowrap">
	<li class="step-item <?php if ($page == 'checkout.php') { ?>active <?php } ?>">
		<a href="#!" class="">Add Address</a>
	</li>
	<li class="step-item <?php if ($page == 'order_review.php') { ?>active <?php } ?>">
		<a href="#!" class="">Order Review</a>
	</li>
	<li class="step-item <?php if ($page == 'payment.php') { ?>active <?php } ?>">
		<a href="#!" class="">Payment</a>
	</li>
	<li class="step-item <?php if ($page == 'order_confirm.php') { ?>active <?php } ?>">
		<a href="#!" class="">Order Confirmation</a>
	</li>
</ul>