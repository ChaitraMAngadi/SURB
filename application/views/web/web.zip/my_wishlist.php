<?php  $this->load->view("web/includes/header_styles"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area mb-3">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="breadcrumb_content">
          <h3>My Wishlist</h3>
          <ul>
            <li><a href="<?php echo base_url()?>web/myaccount">Dashboard</a></li>
            <li>My Wishlist</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!--breadcrumbs area end-->
<!--about section area -->
<section class="dashboard">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-11">
        <div class="row">
          <div class="col-lg-3 col-md-4">
            

            <?php  $this->load->view("web/dashboard_menu"); ?>
          </div>
          <div class="col-lg-9 col-md-12">
            <div class="row">
              <div class="col-lg-12">

                 <?php if (!empty($this->session->flashdata('success_whishlist_message'))) { ?>
                        <div style=" color: red;" class="alert-success"><a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                            <strong> Success!</strong> <?= $this->session->flashdata('success_whishlist_message') ?>
                        </div>
                    <?php } ?>
                    

                <div class="table-responsive" id="no-more-tables">
                  
                  <table class="table table-striped">
                    <thead class="bg-blue text-white">
                      <tr>
                        <th class="product_thumb">Product</th>
                        <th class="product_name">Product Details</th>
                        <th class="product-price">Price</th>
                         <th class="product_remove">Action</th>
                      </tr>
                    </thead>
                    <tbody>
<?php
if(count($data['product_list'])>0){
           foreach($data['product_list'] as $whishlist){ ?>
                      <tr>
                        <td data-title="Product"><a><img src="<?php echo $whishlist['image']; ?>" alt="" class="orderimg"></a></td>
                        <td data-title="Product Details" class="product_name"><a ><?php echo $whishlist['name']; ?></a>
                            <p><a href="<?php echo base_url(); ?>web/store/<?php echo $whishlist['shop_seo_url']; ?>/shop"><b>Shop :</b> <?php echo $whishlist['shop']; ?></a></p>
                        </td>
                        <td data-title="Price" class="product-price"><i class="fal fa-rupee-sign"></i> <?php echo $whishlist['saleprice']; ?></td>
                         <td data-title="Status"><a href="<?php echo base_url();?>web/product_view/<?php echo $whishlist['seo_url']; ?>" class="btn btn-sm btn-success">View </a>

                          <a href="<?php echo base_url();?>web/remove_whishlist/<?php echo $whishlist['id']; ?>" class="btn btn-sm btn-danger">Remove </a></td>
                      </tr>
                      <?php }
                      }else{ ?>
                        <tr>
                          <td colspan="4">
                               <img src="<?php echo base_url();?>/uploads/web_whishlist.png" style="width: 150px">
                                <h4 style="text-align: center;">No Whish List </h4>
                          </td>
                        </tr>
                      <?php }?>

                      
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--about section end-->

<script type="text/javascript">
  
  setTimeout(function() {
    $('.alert-success').fadeOut('fast');
}, 5000);
</script>
<?php include 'includes/footer.php'?>