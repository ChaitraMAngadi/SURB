<?php  $this->load->view("web/includes/header_styles"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area mb-3">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="breadcrumb_content">
          <h3>My Profile</h3>
          <ul>
            <li><a href="<?php echo base_url(); ?>web">Dashboard</a></li>
            <li>My Profile</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!--breadcrumbs area end-->
<!--about section area -->
<section class="dashboard">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-11">
        <div class="row">
          <div class="col-lg-3 col-md-4">
            <?php include 'dashboard_menu.php' ?>
          </div>
          <div class="col-lg-9 col-md-12">

            
            <div class="row justify-content-center">
              <div class="col-lg-9">
                <div id="profile_success_message" class="alert-success"></div>
                <form class="form-horizontal" enctype="multipart/form-data"  >
                  
                
                <div class="row newaddressbox">

                <div class="col-lg-12">
                  <div class="form-group">
                  <label for="">First Name</label>
                <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-user"></i></span>
                  <input type="text" class="form-control" id="profile_first_name" name="first_name" value="<?php echo $profiledata['first_name'] ?>">
                </div>
                  </div>
                </div>

                <div class="col-lg-12">
                  <div class="form-group">
                  <label for="">Last Name</label>
                  <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-user"></i></span>
                  <input type="text" class="form-control" id="profile_last_name" name="last_name" value="<?php echo $profiledata['last_name'] ?>">
                </div>
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="form-group">
                    <label for="">Mobile</label>
                     <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-mobile"></i></span>
                  <input type="text" class="form-control" name="phone" readonly="" value="<?php echo $profiledata['phone'] ?>">
                </div>
                  </div>
                </div>

                 <div class="col-lg-6">
                   <div class="form-group">
                    <label for="">Email</label>
                     <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-envelope"></i></span>
                  <input type="text" class="form-control" name="email" readonly="" value="<?php echo $profiledata['email'] ?>">
                </div>
                   </div>
                 </div>



                 <!-- <div class="col-lg-12">
                   <div class="form-group">
                    <label for="">Current Password</label>
                     <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-key"></i></span>
                  <input type="password" class="form-control" value="xxxxxx">
                </div>
                   </div>
                 </div>

                <div class="col-lg-6">
                  <div class="form-group">
                    <label for="">New Password</label>
                    <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-key"></i></span>
                  <input type="password" class="form-control" value="">
                </div>
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="form-group">
                    <label for="">Confirm Password</label>
                    <div class="input-group mb-3">
                  <span class="input-group-text"><i class="fal fa-key"></i></span>
                  <input type="password" class="form-control" value="">
                </div>
                  </div>
                </div> -->

                <div class="input-group mb-3">
                    <button type="button" onclick="validateprofileForm()" class="btn btn-pink btn-block">UPDATE</button>
                </div>
              
            </div>
            </form>




              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>


<script type="text/javascript">


      function validateprofileForm()
      {
        $('.error').remove();
            var errr=0;
      
      if($('#profile_first_name').val()=='')
      {
         $('#profile_first_name').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter First Name</span>');
         $('#profile_first_name').focus();
         return false;
      }
      else if($('#profile_last_name').val()=='')
      {
         $('#profile_last_name').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Last Name</span>');
         $('#profile_last_name').focus();
         return false;
      }
      else
      {
        var first_name= $('#profile_first_name').val();
        var last_name= $('#profile_last_name').val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/updateUserdata",
              method:"POST",
              data:{first_name:first_name,last_name:last_name},
              success:function(data)
              {
                 var str = data;
                 var res = str.split("@");
                // alert(JSON.stringify(res));
                      if(res[1]=='success')
                        {
                             $('#profile_success_message').html('<span class="error" style="color:green;font-size: 18px;margin-left: 18px; width:100%">Profile Updated success</span>');
                             $('#profile_success_message').focus();


                             //return false; 

                             setTimeout(function() {
                                $('#profile_success_message').hide();

                            }, 10000);
                            
                        }
                        else 
                        {
                            $('#profile_success_message').html('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Something went wrong, Please try again</span>');
                             $('#profile_success_message').focus();
                             return false; 

                        } 

                         window.location.href = "https://sector6.in/web/myprofile";
              }
             });
      }
      

 }



</script>


<!--about section end-->
  <?php  $this->load->view("web/includes/footer"); ?>