<?php  $this->load->view("web/includes/header_styles"); ?>
<!--breadcrumbs area start-->
<div class="breadcrumbs_area mb-3">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="breadcrumb_content">
          <h3>My Addressbook</h3>
          <ul>
            <li><a href="<?php echo base_url()?>web/myaccount">Dashboard</a></li>
            <li>My Addressbook</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<!--breadcrumbs area end-->
<!--about section area -->
<section class="dashboard">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-11">
        <div class="row">
          <div class="col-lg-3 col-md-4">
            <?php include 'dashboard_menu.php' ?>
          </div>
          <div class="col-lg-9 col-md-12">
            <button class="btn btn-blue mb-2" type="button" data-toggle="collapse" data-target="#addnewaddress"><i class="fal fa-plus-circle"></i> Add New Address</button>
            <div class="row newaddressbox collapse" id="addnewaddress">
                    <form class="form-horizontal row" enctype="multipart/form-data"  >
          <div class="col-lg-6 col-md-12">

            <div class="form-group">

              <input type="text" class="form-control" id="name" placeholder="Name">

            </div>

          </div>

          <div class="col-lg-6 col-md-12">

            <div class="form-group">

              <input type="text" class="form-control" id="mobile" placeholder="Mobile No.">

            </div>

          </div>

          <div class="col-lg-12 col-md-12">

            <div class="form-group">

              <input type="text" class="form-control" id="address" placeholder="Address (House No. Building...)">

            </div>

          </div>

          <div class="col-lg-6 col-md-6">
            <div class="form-group">
              <select class="form-control downarrow" id="state" onchange="getCities(this.value)">
                <option value="">Select State</option>
                <?php foreach($states as $state){ ?>
                <option value="<?php echo $state->id; ?>"><?php echo $state->state_name; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div class="col-lg-6 col-md-6">
            <div class="form-group">
              <select class="form-control downarrow" id="cities" onchange="getPincodes(this.value)">
              </select>
            </div>
          </div>

          <div class="col-lg-6 col-md-6">
            <div class="form-group">
              <select class="form-control downarrow" id="pincode">
              </select>
            </div>
          </div>

          <div class="col-lg-6 col-md-6">

            <div class="form-group">

            <input type="text" class="form-control" id="landmark" placeholder="Locaiton / Landmark">

            </div>

          </div>

          <div class="col-lg-12 col-md-12 pt-2">

            <h4>Type of Address</h4>

          </div>

          <div class="col-lg-12">

            <div class="form-check form-check-inline">

              <input class="form-check-input" type="radio" checked="" name="inlineRadioOptions" id="inlineRadio1" value="1">

              <label class="form-check-label" for="inlineRadio1">Home</label>

            </div>

            <div class="form-check form-check-inline">

              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="2">

              <label class="form-check-label" for="inlineRadio2">Office / Commercial</label>

            </div>

            <!-- <div class="form-check form-check-inline">

              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3">

              <label class="form-check-label" for="inlineRadio3">Make this my Default Address</label>

            </div> -->

          </div>

                  <div class="col-lg-12">

                    <button type="button" class="btn btn-address"  onclick="validateAddressForm1()">SAVE ADDRESS</button>

                  </div>
                </form>
            </div>

        <p id="addressmsg"></p>

        <?php
          if(count($addresslist)>0){
         foreach($addresslist as $address){ 
                ?>
            <div class="row">
              <div class="col-lg-12 col-md-12">
                <div class="card p-3 mb-3">
                  <div class="row justify-content-between">
                    <div class="col-lg-8 col-md-7 col-6">
                  <p><strong><?php echo $address['name']; ?></strong> <br>
                  <?php echo $address['address']; ?>,<?php echo $address['landmark']; ?>,<br><?php echo $address['state']; ?>,<?php echo $address['city']; ?> - <?php echo $address['pincode']; ?><br>
                Ph: <?php echo $address['mobile']; ?></p>
                    </div>
                    <div class="col-lg-2 col-md-3 col-4 text-right">
                      <a  class="btn btn-outline-success btn-sm" data-toggle="collapse" data-target="#editaddress<?php echo $address['id']; ?>"><i class="fal fa-edit"></i></a>
                      <a href="<?php echo base_url(); ?>web/deleteaddressinbook/<?php echo $address['id']; ?>"  onclick="if(!confirm('Are you sure you want to delete this address?')) return false;"class="btn btn-outline-danger  btn-sm"><i class="fal fa-trash-alt"></i></a>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>

           <div class="row newaddressbox collapse" id="editaddress<?php echo $address['id']; ?>">
            <div class="col-lg-12">
              <h4>Edit Address</h4>
            </div>
                
         <form class="form-horizontal row" enctype="multipart/form-data"  >
          <div class="col-lg-6 col-md-12">

            <div class="form-group">
              <label>Name : </label>
              <input type="hidden" class="form-control" id="aid" value="<?php echo $address['id']; ?>">
              <input type="text" class="form-control" id="name<?php echo $address['id']; ?>" placeholder="Name" value="<?php echo $address['name']; ?>">

            </div>

          </div>

          <div class="col-lg-6 col-md-12">

            <div class="form-group">
              <label>Mobile : </label>
              <input type="text" class="form-control" id="mobile<?php echo $address['id']; ?>" placeholder="Mobile No." value="<?php echo $address['mobile']; ?>">

            </div>

          </div>

          <div class="col-lg-12 col-md-12">

            <div class="form-group">
              <label>Address : </label>
              <input type="text" class="form-control" id="address<?php echo $address['id']; ?>" placeholder="Address (House No. Building...)" value="<?php echo $address['address']; ?>">

            </div>

          </div>

          <div class="col-lg-6 col-md-6">
            <div class="form-group">
              <label>State : </label>
              <select class="form-control downarrow" id="state<?php echo $address['id']; ?>" onchange="getCities(this.value)">
                <option value="">Select State</option>
                <?php foreach($states as $state){ ?>
                <option value="<?php echo $state->id; ?>" <?php if($state->id==$address['state_id']){ echo "selected='selected'"; }?>><?php echo $state->state_name; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div class="col-lg-6 col-md-6">
            <div class="form-group">
              <label>City : </label>
              <select class="form-control downarrow" id="cities<?php echo $address['id']; ?>" onchange="getPincodes(this.value)">
                <?php
                $city_qry = $this->db->query("select * from cities where state_id='".$address['state_id']."'");
                $city_row = $city_qry->result(); 
                 foreach($city_row as $cit){ ?>
                <option value="<?php echo $cit->id; ?>" <?php if($cit->id==$address['city_id']){ echo "selected='selected'"; }?>><?php echo $cit->city_name; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div class="col-lg-6 col-md-6">
            <div class="form-group">
              <label>City : </label>
              <select class="form-control downarrow" id="pincode<?php echo $address['id']; ?>">
                <?php
                $act_pin = $this->db->where("pincode",$address['pincode'])->get("pincodes")->result()[0]->id;
                $pincode_qry = $this->db->query("select * from pincodes where state_id='".$address['state_id']."' and city_id='".$address['city_id']."'");
                $pincode_result = $pincode_qry->result(); 
                 foreach($pincode_result as $pinc){ ?>
                <option value="<?php echo $pinc->id; ?>" <?php if($pinc->id==$act_pin){ echo "selected='selected'"; }?>><?php echo $pinc->pincode; ?></option>
                <?php } ?>
              </select>
            </div>
          </div>

          <div class="col-lg-6 col-md-6">

            <div class="form-group">
            <label>Landmark : </label>
            <input type="text" class="form-control" id="landmark<?php echo $address['id']; ?>" placeholder="Locaiton / Landmark" value="<?php echo $address['landmark']; ?>">

            </div>

          </div>

          <div class="col-lg-12 col-md-12 pt-2">

            <h4>Type of Address</h4>

          </div>
          <div class="col-lg-12">

            <div class="form-check form-check-inline">

              <input class="form-check-input" type="radio" <?php if($address['address_status']==1){ echo "checked='checked'"; } ?> name="inlineRadioOptions" id="inlineRadio1<?php echo $address['id']; ?>" value="1">

              <label class="form-check-label" for="inlineRadio1">Home</label>

            </div>

            <div class="form-check form-check-inline">

              <input class="form-check-input" type="radio" <?php if($address['address_status']==2){ echo "checked='checked'"; } ?> name="inlineRadioOptions" id="inlineRadio1<?php echo $address['id']; ?>" value="2">

              <label class="form-check-label" for="inlineRadio2">Office / Commercial</label>

            </div>

            <!-- <div class="form-check form-check-inline">

              <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3">

              <label class="form-check-label" for="inlineRadio3">Make this my Default Address</label>

            </div> -->

          </div>

          <div class="col-lg-12">

            <button type="button" class="btn btn-address"  onclick="validateupdateAddressForm1('<?php echo $address['id']; ?>')">UPDATE ADDRESS</button>

          </div>
        </form>
        </div>

      <?php }
      }else{ ?>

          <div class="row">
              <div class="col-lg-12 col-md-12">
                

                 
  <img src="<?php echo base_url();?>/uploads/address.png" style="text-align: center; width: 16%; margin: auto; display: block;">
                <h4 style="text-align: center;">No Address </h4>
                   
            </div>
          </div>


      <?php } ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script type="text/javascript">
  
  function validateupdateAddressForm1(aid)
      {
        $('.error').remove();
            var errr=0;
            var ph = $('#mobile'+aid).val();
      
      if($('#name'+aid).val()=='')
      {
         $('#name'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Name</span>');
         $('#name'+aid).focus();
         return false;
      }
      else if($('#mobile'+aid).val()=='')
      {
         $('#mobile'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Mobile</span>');
         $('#mobile'+aid).focus();
         return false;
      }
       else if(ph.length!=10)
      {
         $('#mobile'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Valid 10 digit Phone Number</span>');
         $('#mobile'+aid).focus();
         return false;
      }  
      else if($('#address'+aid).val()=='')
      {
         $('#address'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Address</span>');
         $('#address'+aid).focus();
         return false;
      }
      else if($('#state'+aid).val()=='')
      {
         $('#state'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Select State</span>');
         $('#state'+aid).focus();
         return false;
      }
      else if($('#cities'+aid).val()=='')
      {
         $('#cities'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Select City</span>');
         $('#cities'+aid).focus();
         return false;
      }
      else if($('#pincode'+aid).val()=='')
      {
         $('#pincode'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Select pincode</span>');
         $('#pincode'+aid).focus();
         return false;
      }
      else if($('#landmark'+aid).val()=='')
      {
         $('#landmark'+aid).after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Landmark</span>');
         $('#landmark'+aid).focus();
         return false;
      }
      else
      {
        var name= $('#name'+aid).val();
        var mobile= $('#mobile'+aid).val();
        var address= $('#address'+aid).val();
        var state= $('#state'+aid).val();
        var cities = $('#cities'+aid).val();
        var pincode = $('#pincode'+aid).val();
        var landmark = $('#landmark'+aid).val();
        var inlineRadio1 = $('#inlineRadio1'+aid).val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/updatebookaddress",
              method:"POST",
              data:{name:name,mobile:mobile,address:address,state:state,cities:cities,pincode:pincode,landmark:landmark,address_type:inlineRadio1,aid:aid},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
                        if(res[1]=='success')
                        {
                          window.location.href = "<?php echo base_url(); ?>web/my_addressbook";

                              $('#addressmsg').html('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Address updated successfully</span>');
                        $('#addressmsg').focus();
                         return false;
                        }
                        else if(res[1]=='nolocation')
                        {
                              $('#pincode').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">No shops in this location,Please change your location</span>');
                        $('#pincode').focus();
                         return false;
                        }
              }
             });
      }
      

 }




      function validateAddressForm1()
      {
        $('.error').remove();
            var errr=0;
            var ph = $('#mobile').val();
      
      if($('#name').val()=='')
      {
         $('#name').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Name</span>');
         $('#name').focus();
         return false;
      }
      else if($('#mobile').val()=='')
      {
         $('#mobile').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Mobile</span>');
         $('#mobile').focus();
         return false;
      }
       else if(ph.length!=10)
      {
         $('#mobile').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Valid 10 digit Phone Number</span>');
         $('#mobile').focus();
         return false;
      }  
      else if($('#address').val()=='')
      {
         $('#address').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Address</span>');
         $('#address').focus();
         return false;
      }
      else if($('#state').val()=='')
      {
         $('#state').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Select State</span>');
         $('#state').focus();
         return false;
      }
      else if($('#cities').val()=='')
      {
         $('#cities').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Select City</span>');
         $('#cities').focus();
         return false;
      }
      else if($('#pincode').val()=='')
      {
         $('#pincode').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Select pincode</span>');
         $('#pincode').focus();
         return false;
      }
      else if($('#landmark').val()=='')
      {
         $('#landmark').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Landmark</span>');
         $('#landmark').focus();
         return false;
      }
      else
      {
        var name= $('#name').val();
        var mobile= $('#mobile').val();
        var address= $('#address').val();
        var state= $('#state').val();
        var cities = $('#cities').val();
        var pincode = $('#pincode').val();
        var landmark = $('#landmark').val();
        var inlineRadio1 = $('#inlineRadio1').val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/addbookaddress",
              method:"POST",
              data:{name:name,mobile:mobile,address:address,state:state,cities:cities,pincode:pincode,landmark:landmark,address_type:inlineRadio1},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
                        if(res[1]=='success')
                        {
                          window.location.href = "<?php echo base_url(); ?>web/my_addressbook";

                              $('#addressmsg').html('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Address added successfully</span>');
                        $('#addressmsg').focus();
                         return false;
                        }
                        else if(res[1]=='nolocation')
                        {
                              $('#pincode').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">No shops in this location,Please change your location</span>');
                        $('#pincode').focus();
                         return false;
                        }

                        
                        
              }
             });
      }
      

 }



function getCities(state_id)
  {
     $.ajax({
              url:"<?php echo base_url(); ?>web/getStates",
              method:"POST",
              data:{state_id:state_id},
              success:function(data)
              {
                       $('#cities').html(data)
          
              }
             });
  }


  function getPincodes(city_id)
  {
    var state_id = $("#state").val();
     $.ajax({
              url:"<?php echo base_url(); ?>web/getaddresspincodes",
              method:"POST",
              data:{state_id:state_id,city_id:city_id},
              success:function(data)
              {
                       $('#pincode').html(data)
          
              }
             });
  }
</script>
<!--about section end-->
<?php include 'includes/footer.php'?>