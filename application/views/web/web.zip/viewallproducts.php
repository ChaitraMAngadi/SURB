<?php  $this->load->view("web/includes/header_styles"); ?>
<!--header area end--><!--breadcrumbs area start-->
<div class="breadcrumbs_area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb_content">
                    <h3><?php echo $title; ?></h3>
                    <ul>
                        <li><a href="<?php echo base_url(); ?>">home</a></li>
                        <li><?php echo $title; ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--breadcrumbs area end-->
<div id="show_errormsg1"></div>

<div class="shop_area mb-80">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-md-12">
                <!--shop wrapper start-->
                
                <!--shop toolbar start-->
                <!-- <div class="shop_toolbar_wrapper">
                    <div class="page_amount">
                        <p>Showing 1–12 of 21 results</p>
                    </div>
                    <div class="niceselect_option">
                        <form class="select_option" action="#">
                            <select name="orderby" id="short">
                                <option selected value="1">Sort by</option>
                                <option  value="2">Price - High to Low</option>
                                <option value="3">Popularity</option>
                                <option value="4">Discount</option>
                                <option value="5">Price - Low to High</option>
                            </select>
                        </form>
                    </div>
                </div> -->
                <!--shop toolbar end-->
                <div id="fav_msg" style="text-align: center;"></div>
                <div class="row shop_wrapper" id="products_list">
                    <?php foreach($products as $deals){ ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                        <div class="single_product">
                            <div class="product_thumb">
                                <a class="primary_img" href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><img src="<?php echo $deals['image']; ?>" alt=""></a>
                                <a class="secondary_img" href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><img src="<?php echo $deals['image']; ?>" alt=""></a>

                                <div class="wishlist">
                                    <a title="Add to Wishlist" onclick="addFavorite(<?php echo $deals['id']; ?>)">
                                      <span id="bestselling_pro_<?php echo $deals['id']; ?>" class="<?php if($deals['whishlist_status']==true){ echo 'fas'; }else{ echo 'fal'; } ?> fa-heart"></span>
                                    </a>
                                  </div>
                            </div>
                            <div class="product_content grid_content">
                                 <a href="<?php echo base_url(); ?>web/product_view/<?php echo $deals['seo_url']; ?>"><div class="product_content_inner">
                                    <h4 class="product_name"><a><?php echo $deals['name']; ?></a></h4>
                                    <p class="shop-name"><?php echo $deals['shop']; ?></p>
                                    <div class="price_box">
                                        <span class="current_price"><i class="fal fa-rupee-sign"></i> <?php echo $deals['saleprice']; ?></span>
                                    </div>
                                </div></a>
                                <div class="add_to_cart">
                                    <a  onclick="addtocart(<?php echo $deals['variant_id']; ?>,<?php echo $deals['shop_id']; ?>,'<?php echo $deals['saleprice']; ?>',1)"><i class="fal fa-shopping-cart fa-lg"></i> Add to cart</a>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <?php } ?>
                </div>

                <style>
                            .pagination_new {
                                text-align: center;
                            }
                            .pagination_new a {
                                padding: 10px 15px;
                                background-color: #ccc;
                                color: #333;
                                    margin: 0px 1px;
                            }
                            .pagination_new strong {
                                padding: 10px 15px;
                                background-color: #cf1673;
                                color: #fff;
                                margin: 0px 1px;
                            }
                        </style>
                        <div class="pagination_new">
                            <p><?php echo $links; ?></p>
                        </div>
                <!-- <div class="shop_toolbar t_bottom">
                    <div class="pagination">
                        <ul>
                            <li class="current">1</li>
                            <li><a href="#">2</a></li>
                            <li><a href="#">3</a></li>
                            <li class="next"><a href="#">next</a></li>
                            <li><a href="#">>></a></li>
                        </ul>
                    </div>
                </div> -->
                <!--shop toolbar end-->
                <!--shop wrapper end-->
            </div>
            
            
        </div>
    </div>
</div>
<script type="text/javascript">
    function addFavorite(pid)
  {
    var user_id = '<?php echo $_SESSION['userdata']['user_id']; ?>';
      if(user_id=='')
      {
        $('#loginModal').modal('show');
        return false;
      }
      else
      {

            $('.error').remove();
            var errr=0;
            $.ajax({
              url:"<?php echo base_url(); ?>web/add_remove_favourite",
              method:"POST",
              data:{pid:pid},
              success:function(data)
              {
                 var str = data;
                 var res = str.split("@");
              
                  if(res[1]=='remove')
                  {
                     $("#bestselling_pro_"+pid).removeClass("fas");
                      $("#bestselling_pro_"+pid).addClass("fal");
                  }
                  else if(res[1]=='add')
                  {
                      $("#bestselling_pro_"+pid).removeClass("fal");
                      $("#bestselling_pro_"+pid).addClass("fas");
                  }
                      
                        
              
              }
             });
      }
  }


    /*function addtocart(variant_id,vendor_id,saleprice,quantity)
    {
      var user_id = '<?php echo $_SESSION['userdata']['user_id']; ?>';
      if(user_id=='')
      {

        $('#loginModal').modal('show');
        return false;

      }
      else
      {

              var session_vendor_id = '<?php echo $_SESSION['session_data']['vendor_id']; ?>';
              var cart_count= '<?php echo $cart_count; ?>';
              if(session_vendor_id!=vendor_id && cart_count>0)
              {

              if(confirm("Are you sure you want to Clear the previous store items"))
              {

                  $('.error').remove();
                  var errr=0;

                  $.ajax({
                    url:"<?php echo base_url(); ?>web/addtocart",
                    method:"POST",
                    data:{variant_id:variant_id,vendor_id:vendor_id,saleprice:saleprice,quantity:quantity},
                    success:function(data)
                    {
                       var str = data;
                    var res = str.split("@");
                        if(res[1]=='success')
                        {
                          $('html, body').animate({
                              scrollTop: $('#show_errormsg1').offset().top - 100 //#DIV_ID is an example. Use the id of your destination on the page
                          }, 'slow');
                          $('#cart_count').html(res[2]);
                            $('#show_errormsg').html('<span class="error" style="color:green;font-size: 16px;margin-left: 18px; width:100%">Product added to cart</span>');
                            $('#show_errormsg').focus();
                              return false;
                        }
                        else
                        {
                            $('#show_errormsg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">OUT OF STOCK</span>');
                            $('#show_errormsg').focus();
                              return false;
                        }
                    }
                   });
                }
              }
              else
              {
                  $('.error').remove();
                  var errr=0;

                  $.ajax({
                    url:"<?php echo base_url(); ?>web/addtocart",
                    method:"POST",
                    data:{variant_id:variant_id,vendor_id:vendor_id,saleprice:saleprice,quantity:quantity},
                    success:function(data)
                    {
                       var str = data;
                    var res = str.split("@");
                        if(res[1]=='success')
                        {

                           $('html, body').animate({
                              scrollTop: $('#show_errormsg1').offset().top - 100 //#DIV_ID is an example. Use the id of your destination on the page
                          }, 'slow');

                          $('#cart_count').html(res[2]);
                               $('#show_errormsg').html('<span class="error" style="color:green;font-size: 16px;margin-left: 18px; width:100%">Product added to cart</span>');
                            $('#show_errormsg').focus();
                              return false;
                        }
                        else
                        {
                            $('#show_errormsg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">OUT OF STOCK</span>');
                            $('#show_errormsg').focus();
                              return false;
                        }
                            
                              
                    
                    }
                   });
                
              }
      }
    }*/

</script>
<?php  $this->load->view("web/includes/footer"); ?>