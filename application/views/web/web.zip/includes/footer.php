   
<?php
    $session_id = $_SESSION['session_data']['session_id'];
    $user_id= $_SESSION['userdata']['user_id'];
    $cart_qry = $this->db->query("select * from cart where session_id='".$session_id."' and user_id='".$user_id."'");
       $cart_count = $cart_qry->num_rows();    
 ?>

 <input type="hidden" id="cart_count_hidden_input" value="<?php echo $cart_count; ?>">
<input type="hidden" id="session_id" value="<?php echo $session_id; ?>">
<input type="hidden" id="vendor_id" value="<?php echo $_SESSION['session_data']['vendor_id']; ?>">

    <!--footer area start-->
<input type="hidden" id="login_quantity" >
<input type="hidden" id="login_vendor_id" >
<input type="hidden" id="login_session_id">
<input type="hidden" id="login_variant_id" >
<input type="hidden" id="login_saleprice" >
    <footer class="footer_widgets"> 

        <div class="container">

            

            <div class="footer_middle">

            	<div class="row">

                 <div class="col-lg-10 offset-lg-1">

                     <div class="row">

                     <div class="col-lg-3 col-md-6 col-6">

                        <h4>Categories</h4>

                        <ul class="links">
                            <?php 
                              $i=1;
                            foreach($categories as $category)
                            { 
                              if($i<5){
                              ?>
                                <li><a href="<?php echo base_url(); ?>web/store_categories/<?php echo $category['seo_url']; ?>"><?php echo $category['title']; ?></a></li>
                            <?php } 
                            $i++;
                            } ?>

                            <!-- <li><a href="#">Furniture</a></li>

                            <li><a href="#">Mobiles</a></li>

                            <li><a href="#">Electornics</a></li>

                            <li><a href="#">Fashion</a></li>  -->

                        </ul>

                    </div> 

                     <div class="col-lg-3 col-md-6 col-6">

                        <h4>Policy Links</h4>

                        <ul class="links">

                            <li><a href="<?php echo base_url();?>web/privacy_policy">Privacy Policy</a></li>

                            <li><a href="<?php echo base_url();?>web/refund_policy">Cancellation and Refund Policy</a></li>

                            <li><a href="<?php echo base_url();?>web/terms_and_conditions">Terms and Conditions</a></li>

                              <li><a href="<?php echo base_url();?>web/delivery_partner">Delivery Partner</a></li>
                              <li><a href="<?php echo base_url();?>web/shipping_policy">Shipping Policy</a></li>
                        </ul>

                    </div> 

                    <div class="col-lg-3 col-md-6 col-12">

                         <h4>Follow Us</h4>

                        <div class="footer_social">

                            <ul>

                                <li><a href="" target="_blank"><i class="fab fa-facebook-f" aria-hidden="true"></i></a></li>

                                <li><a href="" target="_blank"><i class="fab fa-twitter" aria-hidden="true"></i></a></li>

                                <li><a href="" target="_blank"><i class="fab fa-youtube" aria-hidden="true"></i></a></li>

                                <li><a href="" target="_blank"><i class="fab fa-instagram" aria-hidden="true"></i></a></li>

                            </ul>

                        </div> 

                    </div>

                    <div class="col-lg-3 col-md-6 col-12">
                        <h4>Download Our App</h4>
                        <div class="app-links">
                            <a href="" target="_blank" class="mb-2 mr-2">
                                <img src="<?php echo base_url();?>web_assets/img/app-logo-two.png" alt="" width="120" style="height:38px">
                            </a>
                            <a href="" target="_blank" class="mb-0">
                                <img src="<?php echo base_url();?>web_assets/img/app-logo-one.png" alt="" width="120" style="height:38px">
                            </a> 

                        </div> 
                    </div>



                   <!--  <ul class="" style="color: #fff;" >

                            <li style="float: left; margin-left: 10px;"><a href="<?php echo base_url();?>web/privacy_policy">Privacy Policy</a>  |  </li> 

                            <li style="float: left; margin-left: 10px;"><a href="<?php echo base_url();?>web/refund_policy">Refund and Return Policy</a> | </li>

                            <li style="float: left; margin-left: 10px;"><a href="<?php echo base_url();?>web/terms_and_conditions">Terms and Conditions</a></li>

                        </ul> -->


                </div>

                 </div>   

                </div>

            </div>

            <div class="footer_bottom">  

                <div class="row align-items-center">

                    <div class="col-lg-8 col-md-8">

                        <div class="footer_bottom_left">

                        	<div class="footer_logo">

							   <a href="#"><img src="<?php echo base_url();?>web_assets/img/logo-white.png" alt=""></a>

							</div>

                        	<div class="copyright_area">

								<p>Copyright  © 2021  <a href="https://sector6.in/" target="_blank">https://sector6.in</a> All rights reserved.  <!-- Design &amp; Developed By<a href="https://thecolourmoon.com/" target="_blank">Colourmoon</a> --></p>

							</div>

                        </div>

                    </div> 

                    <div class="col-lg-4 col-md-4">

                       <div class="footer_paypal text-right">

                       		<a href="#"><img src="<?php echo base_url();?>web_assets/img/icon/payment.png" alt=""></a>	


                       </div>

                    </div>    

                </div>     

            </div>  

        </div>    

    </footer>

    <!--footer area end-->

   

   <!--loginmodal-start-->

   <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-body">

        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"><i class="fal fa-times-circle"></i></button>

        <div class="row justify-content-end">

            <div class="col-lg-6">

                <h4>LOGIN</h4>
                <div id="login_show_errormsg"></div>
              <form class="form-horizontal" enctype="multipart/form-data"  >
                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-envelope-open"></i></span>

                  <input type="text" class="form-control" id="email" name="email" placeholder="Mobile or Email Address">

                </div>

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-key"></i></span>

                  <input type="password" class="form-control" id="password" name="password" placeholder="Password">

                </div>

                <div class="input-group mb-3">

                    <a onclick="goForgot()" class="w-100 text-right">Forgot Password?</a>

                </div>

                <div class="input-group mb-3">
                    <button type="button" onclick="validateloginForm()" class="btn btn-pink btn-block">LOGIN</button>
                    <p>Don't have an Account? <!-- <a href="#registerModal" data-toggle="modal" data-dismiss="modal">Register</a> --><a onclick="showRegistration()" data-toggle="modal" data-dismiss="modal">Register</a>
                    </p>
                </div>

              </form>


            </div>

        </div>

      </div>

    </div>

  </div>

</div>


<script type="text/javascript">

document.onkeydown = function(e) {
  if(event.keyCode == 123) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
     return false;
  }
  if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
     return false;
  }
}




  function showRegistration()
  {
    $('#email').val("");
    $('#password').val("");
    $('#registerModal').modal('show');

  }
   // $('#btn_register').click(function(){

      function goForgot()
      {
             document.getElementById("showforgotform").style.display = "block";
             document.getElementById("showresetform").style.display = "none";
             $('#loginModal').modal('hide');
             $('#forgotModal').modal('show');
            

      }


      function validateloginForm()
      {
        $('.error').remove();
            var errr=0;
      
            var login_quantity = $('#login_quantity').val();
            var login_vendor_id = $('#login_vendor_id').val();
            var login_session_id = $('#login_session_id').val();
            var login_variant_id = $('#login_variant_id').val();
            var login_saleprice = $('#login_saleprice').val();


      if($('#email').val()=='')
      {
         $('#email').after('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Enter Mobile or  Email Address</span>');
         $('#email').focus();
         return false;
      }
      else if($('#password').val()=='')
      {
         $('#password').after('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Enter Password</span>');
         $('#password').focus();
         return false;
      }
      else
      {
        var email= $('#email').val();
        var password= $('#password').val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/userLogin",
              method:"POST",
              data:{username:email,password:password},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
                  if(res[1]=='success')
                  {
                  	//alert(login_quantity);
                  			if(login_quantity!='')
                  			{
                  					addtocartWithoutLogin(login_variant_id,login_vendor_id,login_saleprice,login_quantity,login_session_id,res[2]);

                  				 	var loc = '<?php echo $_SERVER['REQUEST_URI']; ?>';
                  				 	
                          			window.location.href = "https://sector6.in/"+loc;
                  			}
                  			else
                  			{
                  				window.location.href = "<?php echo base_url(); ?>web";
                  			}
                  			

                          
                  }
                  else if(res[1]=='location')
                  {
                          window.location.href = "<?php echo base_url(); ?>web/googlemap";
                  }
                  else 
                  {
                      $('#login_show_errormsg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Invalid Login Details,Please try again</span>');
                      $('#show_errormsg').focus();
                        return false;
                  }
                      
                        
              
              }
             });
      }
  }
      

 

function validateEmail($email) 
{
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if( !emailReg.test( $email) ) {
      return false;
    } 
    else
    {
        return true;
    }
}

</script>



   <!--loginmodal-end-->

 

   <!--forgotmodal-start-->

   <div class="modal fade" id="forgotModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-body">

        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"><i class="fal fa-times-circle"></i></button>

        <div class="row justify-content-end">

            <div class="col-lg-6" id="showforgotform">

                <h4>FORGOT PASSWORD</h4>

                <p class="pb-3">Enter your email address and we'll send <br>you a link to reset your password.</p>
                <div id="forgot_show_errormsg"></div>
                  <form class="form-horizontal" enctype="multipart/form-data"  >
                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-envelope-open"></i></span>

                  <input type="text" class="form-control" id="username" name="username" placeholder="Mobile or Email Address">

                </div>

                <div class="input-group mb-3">

                    <button type="button" onclick="validateForgotPassword()" class="btn btn-pink btn-block">SUBMIT</button>

                </div>
              </form>

            </div>

            <div class="col-lg-6" id="showresetform">

                <h4>RESET PASSWORD</h4>

                <p class="pb-3">Enter your email address and we'll send <br>you a link to reset your password.</p>

                  <form class="form-horizontal" enctype="multipart/form-data"  >

                  <input type="hidden" id="forgot_user_id" name="user_id">

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-password-open"></i></span>

                  <input type="number" class="form-control" id="fotp" name="otp" maxlength="4" placeholder="Enter OTP">

                </div>

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-password-open"></i></span>

                  <input type="password" class="form-control" id="npassword" name="password" placeholder="New Password">

                </div>

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-password-open"></i></span>

                  <input type="password" class="form-control" id="ncpassword" name="cpassword" placeholder="Confirm Password">

                </div>


                <div class="input-group mb-3">

                    <button type="button" onclick="validateResetPassword()" class="btn btn-pink btn-block">SUBMIT</button>

                </div>
              </form>

            </div>

        </div>

      </div>

    </div>

  </div>

</div>

<script type="text/javascript">
  
      function validateForgotPassword()
      {
        $('.error').remove();
            var errr=0;
      
      if($('#username').val()=='')
      {
         $('#username').after('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Enter Mobile or  Email Address</span>');
         $('#username').focus();
         return false;
      }
      else
      {
            var username = $('#username').val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/forgotPassword",
              method:"POST",
              data:{username:username},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
                  if(res[1]=='success')
                  {
                          document.getElementById("forgot_user_id").value = res[2];

                          document.getElementById("showforgotform").style.display = "none";
                          document.getElementById("showresetform").style.display = "block";
                          /*$('#forgotModal').modal('show');
                          $('#loginModal').modal('hide');*/
                  }
                  else
                  {
                    $('#forgot_show_errormsg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Invalid Email or Phone Number</span>');
                       $('#forgot_show_errormsg').focus();
                        return false;
                  }
                      
                        
              
              }
             });
      }
      

 }

function validateResetPassword()
{
        $('.error').remove();
            var errr=0;
      
      if($('#fotp').val()=='')
      {
         $('#fotp').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter OTP</span>');
         $('#fotp').focus();
         return false;
      }
      else if($('#npassword').val()=='')
      {
         $('#npassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter New Password</span>');
         $('#npassword').focus();
         return false;
      }
       else if($('#ncpassword').val()=='')
      {
         $('#ncpassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Confirm Password</span>');
         $('#ncpassword').focus();
         return false;
      }
      else if($('#npassword').val()!=$('#ncpassword').val())
      {
         $('#npassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Password Mismatched</span>');
         $('#npassword').focus();
         return false;
      }
      else
      {
        var otp= $('#fotp').val();
        var user_id= $('#forgot_user_id').val();
        var npassword= $('#npassword').val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/resetPassword",
              method:"POST",
              data:{otp:otp,user_id:user_id,password:npassword},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
                        if(res[1]=='success')
                        {
                           window.location.href = "<?php echo base_url(); ?>web/myprofile";
                        }
                        else
                        {
                           $('#fotp').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Invalid OTP</span>');
                              $('#fotp').focus();
                            return false;


                        }
                       
              }
             });
      }
      

 }


</script>

   <!--forgotmodal-end-->

  <!--registermodal-start-->

   <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-body">

        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"><i class="fal fa-times-circle"></i></button>

        <div class="row justify-content-end">

            <div class="col-lg-6">

                <h4>REGISTER</h4>
                <form class="form-horizontal" enctype="multipart/form-data"  >

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-user"></i></span>

                  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="First Name">

                </div>

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-user"></i></span>

                  <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last Name">

                </div>

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-mobile"></i></span>

                  <input type="number" class="form-control" id="mobile" name="mobile" placeholder="Mobile No." maxlength="10">

                </div>

                 <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-envelope"></i></span>

                  <input type="text" class="form-control" id="reg_email" name="email" placeholder="Email Address">

                </div>

                 <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-key"></i></span>

                  <input type="password" class="form-control" id="newpassword" name="password" placeholder="Password">

                </div>

                <div class="input-group mb-3">

                  <span class="input-group-text"><i class="fal fa-key"></i></span>

                  <input type="password" class="form-control"  id="regcpassword" name="cpassword" placeholder="Confirm Password">

                </div>

                <div class="input-group mb-3">

                    <!-- <button type="submit" id="btn_register" class="btn btn-pink btn-block" data-toggle="modal" data-target="#otpModal" data-dismiss="modal">SIGNUP</button> -->

                    <button type="button"  onclick="validateForm()" class="btn btn-pink btn-block">SIGNUP</button>

                    <p>Already have an Account? <a onclick="showLogin()" data-toggle="modal" data-dismiss="modal">Login</a></p>

                </div>
              </form>

            </div>

        </div>

      </div>

    </div>

  </div>

</div>


<script type="text/javascript">
   // $('#btn_register').click(function(){

    function showLogin()
  {
    $('#first_name').val("");
    $('#last_name').val("");
    $('#mobile').val("");
    $('#reg_email').val("");
    $('#newpassword').val("");
    $('#loginModal').modal('show');

  }


      function validateForm()
      {
        $('.error').remove();
            var errr=0;
            var ph = $('#mobile').val();
             var pass = $('#newpassword').val();
      
      if($('#first_name').val()=='')
      {
         $('#first_name').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter First Name</span>');
         $('#first_name').focus();
         return false;
      }
      else if($('#last_name').val()=='')
      {
         $('#last_name').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Last Name</span>');
         $('#last_name').focus();
         return false;
      }
       else if($('#mobile').val()=='')
      {
         $('#mobile').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Mobile</span>');
         $('#mobile').focus();
         return false;
      }
       else if(ph.length!=10)
      {
         $('#mobile').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Valid 10 digit Phone Number</span>');
         $('#mobile').focus();
         return false;
      }  
      else if($('#reg_email').val()=='')
      {
         $('#reg_email').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Email</span>');
         $('#reg_email').focus();
         return false;
      }
      else if(!validateEmail($('#reg_email').val())) 
     { 
       $('#reg_email').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Invalid Email Address</span>');
       $('#reg_email').focus();
        return false;
     }
      else if($('#newpassword').val()=='')
      {
         $('#newpassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Password</span>');
         $('#newpassword').focus();
         return false;
      }
      else if(pass.length<6)
      {
         $('#newpassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Password must be more than 5 digits</span>');
         $('#newpassword').focus();
         return false;
      }
       else if($('#regcpassword').val()=='')
      {
         $('#regcpassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Enter Confirm Password</span>');
         $('#regcpassword').focus();
         return false;
      }
      else if($('#newpassword').val()!=$('#regcpassword').val())
      {
         $('#regcpassword').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Password Mismatched</span>');
         $('#regcpassword').focus();
         return false;
      }
      else
      {
        var first_name= $('#first_name').val();
        var last_name= $('#last_name').val();
        var mobile= $('#mobile').val();
        var email= $('#reg_email').val();
        var password= $('#newpassword').val();
            $.ajax({
              url:"<?php echo base_url(); ?>web/userRegister",
              method:"POST",
              data:{first_name:first_name,last_name:last_name,mobile:mobile,email:email,password:password},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              //alert(JSON.stringify(res));
                        if(res[1]=='success')
                        {
                            $('#first_name').val("");
                            $('#last_name').val("");
                            $('#mobile').val("");
                            $('#reg_email').val("");
                            $('#newpassword').val("");
                            document.getElementById("otp_phone").value = res[2];
                            $('#phone_data').html(mobile);
                            $('#otpModal').modal('show');
                            $('#registerModal').modal('hide');
                        }
                        else if(res[1]=='both')
                        {
                             $('#reg_email').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Email already Exist</span>');
                             $('#reg_email').focus();
                             $('#mobile').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Phone Number Already Exist</span>');
                             $('#mobile').focus();
                             return false;
                        }
                        else if(res[1]=='invalid_email')
                        {
                            $('#reg_email').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Email Already Exist</span>');
                            $('#reg_email').focus();
                            return false;  
                        }
                        else if(res[1]=='invalid_phone')
                        {
                             $('#mobile').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Phone Number Already Exist</span>');
                             $('#mobile').focus();
                             return false; 
                        }
              }
             });
      }
      

 }

function validateEmail($email) 
{
    var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    if( !emailReg.test( $email) ) {
      return false;
    } 
    else
    {
        return true;
    }
}

</script>

   <!--registermodal-end-->

    <!--otpmodal-start-->

   <div class="modal fade" id="otpModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-body">

        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"><i class="fal fa-times-circle"></i></button>

        <div class="row justify-content-end">

            <div class="col-lg-6">

                <h4>OTP VERIFICATION</h4>
                  <div id="resend_success_msg"></div>
                <p class="pb-3">Sent OTP to <span>+91 </span><span id="phone_data"></span></p>
            <form class="form-horizontal" enctype="multipart/form-data"  >

              <input type="hidden" name="user_id" id="otp_phone">

                <div class="input-group mb-3">


                  <input type="number" id="verify_otp" name="otp" class="form-control" placeholder="OTP" maxlength="4">

                </div>


                <!-- <div class="row input-group mb-3">
                      <input type="hidden" name="user_id" id="otp_phone">
                    <div class="col-12">
                      <input type="number" id="verify_otp" name="otp" class="form-control" placeholder="OTP" maxlength="4">
                    </div>

                    <div class="col-3"><input type="text" class="form-control" placeholder="0"></div>

                    <div class="col-3"><input type="text" class="form-control" placeholder="0"></div>

                    <div class="col-3"><input type="text" class="form-control" placeholder="0"></div>

                </div> -->
                  <br> 
                <div class="input-group mb-3">

                    <button type="button" onclick="ValidateOTP()" class="btn btn-pink btn-block">VERIFY</button>

                    <p>Didn't Receive Code <a onclick="resendOTP()">Resend</a></p>

                </div>

          </form>

            </div>

        </div>

      </div>

    </div>

  </div>

</div>

<script type="text/javascript">

  function resendOTP()
  {
    $('.error').remove();
            var errr=0;
        var user_id= $('#otp_phone').val();
        
            $.ajax({
              url:"<?php echo base_url(); ?>web/resendOTP",
              method:"POST",
              data:{user_id:user_id},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              if(res[1]=='success')
                {
                  $('#resend_success_msg').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">OTP sent to your Mobile Number</span>');
                  $('#resend_success_msg').focus();
                   return false;

                }
                else
                {
                  $('#resend_success_msg').after('<span class="error" style="color:red;font-size: 18px;margin-left: 18px; width:100%">Something went wrong , Please try again</span>');
                  $('#resend_success_msg').focus();
                   return false;
                  
                }
                      
                        
              }
             });
  }

   function ValidateOTP()
   {
        $('.error').remove();
            var errr=0;
      
      if($('#verify_otp').val()=='')
      {
         $('#verify_otp').after('<span class="error" style="color:red;font-size: 18px;margin-top: -11px; width:100%">Enter OTP</span>');
         $('#verify_otp').focus();
         return false;
      }
      else
      {
        var otp= $('#verify_otp').val();
        var user_id= $('#otp_phone').val();
        
            $.ajax({
              url:"<?php echo base_url(); ?>web/OTPVerification",
              method:"POST",
              data:{otp:otp,user_id:user_id},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
              if(res[1]=='success')
                {
                        window.location.href = "<?php echo base_url(); ?>web/myprofile";
                }
                else
                {
                  $('#verify_otp').after('<span class="error" style="color:red;font-size: 18px; margin-top: -11px; width:100%">Invalid OTP</span>');
                  $('#verify_otp').focus();
                  return false;
                }
                      
                        
              }
             });
      }
      

 }

</script>

   <!--otpmodal-end-->

   <!--bidmodal-start-->

<div class="modal fade" id="bidModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h5 class="modal-title" id="exampleModalLabel"><i class="fas fa-comment-exclamation fa-lg"></i> HOW BID WORKS</h5>

        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"><i class="fal fa-times-circle fa-lg"></i></button>

      </div>

      <div class="modal-body">

            <p>It enables you to get the best price for items on your Bag.</p>

            <p><strong>What you have to do is..</strong></p>

            <ul>

                <li>Add items to your Bag make sure they are of same category.</li>

                <li>PRESS the "Get the bid" option available in your cart.</li>

                <li>That's all you have done your part successfully.</li>

                <li>Now wait for the vendors of that category in your location to receive the bid request and respond to it with their respective quote.</li>

                <li>You can check their quotes in my bids page from where you can select the most impressive id and can place the order.</li>

            </ul>

      </div>

    </div>

  </div>

</div>



<script type="text/javascript">
 function confirmnewCart(variant_id,vendor_id,saleprice,quantity){
        var id = $(this).parents("tr").attr("id");

       swal({

        title: "Are you sure?",

        text: "You want to Clear the previous store items",

        type: "warning",

        showCancelButton: true,

        confirmButtonClass: "btn-danger",

        confirmButtonText: "Yes",

        cancelButtonText: "Cancel",

        closeOnConfirm: false,

        closeOnCancel: false

      },

      function(isConfirm) {

        if (isConfirm) {

                  $.ajax({
                    url:"<?php echo base_url(); ?>web/addtocart",
                    method:"POST",
                    data:{variant_id:variant_id,vendor_id:vendor_id,saleprice:saleprice,quantity:quantity},
                    success:function(data)
                    {
                        var str = data;
                        var res = str.split("@");
                        if(res[1]=='success')
                        {
                          $("#vendor_id").val(vendor_id);
                          $("#session_id").val(res[3]);
                              $('#cart_count').html(res[2]);  
                          
                               swal("Product added to cart!")
                        }
                        else if(res[1]=='shopclosed')
                        {
                           
                              swal("Shop Closed!")
                        }
                        else
                        {
                              swal("OUT OF STOCK!")
                        }
                            
                              
                    
                    }
                   });
                

        } else {

          swal("Cancelled", "", "error");

        }

      });

     

    }


  
    function addtocart(variant_id,vendor_id,saleprice,quantity)
    {
      var session_vendor_id = $("#vendor_id").val();
      //alert(session_vendor_id);
      var session_id = $("#session_id").val();
      var user_id = '<?php echo $_SESSION['userdata']['user_id']; ?>';


      if(user_id=='')
      {
      	$("#login_quantity").val(quantity);
        $("#login_vendor_id").val(vendor_id);
        $("#login_session_id").val(session_id);

        $("#login_variant_id").val(variant_id);
        $("#login_saleprice").val(saleprice);

        $('#loginModal').modal('show');
        return false;
      }
      else
      {
              if(session_vendor_id!=vendor_id && session_vendor_id!='')
              {
                    confirmnewCart(variant_id,vendor_id,saleprice,quantity);
              }
              else
              {
                  $('.error').remove();
                  var errr=0;

                  $.ajax({
                    url:"<?php echo base_url(); ?>web/addtocart",
                    method:"POST",
                    data:{variant_id:variant_id,vendor_id:vendor_id,saleprice:saleprice,quantity:quantity,session_id:session_id},
                    success:function(data)
                    {
                       var str = data;
                    var res = str.split("@");
                        if(res[1]=='success')
                        {
                          $("#vendor_id").val(vendor_id);
                          $("#session_id").val(res[3]);
                          $('#cart_count').html(res[2]);
                           
                              swal("Product added to cart!")
                        }
                        else if(res[1]=='shopclosed')
                        {
                           
                              swal("Shop Closed!")
                        }
                        else
                        {
                              swal("OUT OF STOCK!")
                        }
                    }
                   });
                
              }
      }
    }



function addtocartWithoutLogin(variant_id,vendor_id,saleprice,quantity,session_id,user_id)
{
                  $('.error').remove();
                  var errr=0;

                  $.ajax({
                    url:"<?php echo base_url(); ?>web/addtocartWithoutLogin",
                    method:"POST",
                    data:{variant_id:variant_id,vendor_id:vendor_id,saleprice:saleprice,quantity:quantity,session_id:session_id,user_id:user_id},
                    success:function(data)
                    {
                       var str = data;
                    var res = str.split("@");
                        if(res[1]=='success')
                        {
                          $("#vendor_id").val(vendor_id);
                          $("#session_id").val(res[3]);
                          $('#cart_count').html(res[2]);
                           
                              swal("Product added to cart!")
                        }
                        else if(res[1]=='shopclosed')
                        {
                           
                              swal("Shop Closed!")
                        }
                        else
                        {
                              swal("OUT OF STOCK!")
                        }
                    }
                   });
    }
</script>



<!--bidmodal-end-->

<!-- JS

============================================ -->

<!--sweetalert-->

 <script src="<?php echo base_url();?>web_assets/js/sweetalert.js"></script>

    <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/sweetalert.css" />
<!--close sweetalert-->


<script src="<?php echo base_url();?>web_assets/js/vendor/jquery-3.4.1.min.js"></script>

<!--popper min js-->

<script src="<?php echo base_url();?>web_assets/js/popper.js"></script>

<!--bootstrap min js-->

<script src="<?php echo base_url();?>web_assets/js/bootstrap.min.js"></script>

<!--owl carousel min js-->

<script src="<?php echo base_url();?>web_assets/js/owl.carousel.min.js"></script>

<!--slick min js-->

<script src="<?php echo base_url();?>web_assets/js/slick.min.js"></script>

<!--magnific popup min js-->

<script src="<?php echo base_url();?>web_assets/js/jquery.magnific-popup.min.js"></script>

<!--jquery countdown min js-->

<script src="<?php echo base_url();?>web_assets/js/jquery.countdown.js"></script>

<!--jquery ui min js-->

<script src="<?php echo base_url();?>web_assets/js/jquery.ui.js"></script>

<!--jquery elevatezoom min js-->

<script src="<?php echo base_url();?>web_assets/js/jquery.elevatezoom.js"></script>

<!--isotope packaged min js-->

<script src="<?php echo base_url();?>web_assets/js/isotope.pkgd.min.js"></script>

<!-- Plugins JS -->

<script src="<?php echo base_url();?>web_assets/js/plugins.js"></script>



<!-- Main JS -->

<script src="<?php echo base_url();?>web_assets/js/main.js"></script>

<script src="<?php echo base_url();?>web_assets/js/sidebar.js"></script>





</body>

</html>