<!doctype html>
<html class="no-js" lang="en">
    <head>
        <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-TR5YWBG83H"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-TR5YWBG83H');
</script>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta property="al:android:app_name" content="App Links" />
        <title>Sector6 - Its A Facile Shoppy</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>web_assets/img/favicon.png">
        
        <!-- CSS
        ========================= -->
        <!--bootstrap min css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/bootstrap.min.css">
        <!--owl carousel min css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/owl.carousel.min.css">
        <!--slick min css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/slick.css">
        <!--magnific popup min css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/magnific-popup.css">
        <!--font awesome css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/all.css">
        <!--ionicons css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/ionicons.min.css">
        <!--7 stroke icons css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/pe-icon-7-stroke.css">
        <!--animate css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/animate.css">
        <!--jquery ui min css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/jquery-ui.min.css">
        <!--plugins css-->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/plugins.css">
        
        <!-- Main Style CSS -->
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/style.css">
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/costumnew.css">
        <link rel="stylesheet" href="<?php echo base_url();?>web_assets/css/newresponsive.css">
        
        <!--modernizr min js here-->
        <script src="<?php echo base_url();?>web_assets/js/vendor/modernizr-3.7.1.min.js"></script></head>
        <body oncut="return false" onpaste="return false" oncontextmenu="return false;">
            <!--offcanvas menu area start-->
            <div class="off_canvars_overlay">
                
            </div>
            <div class="offcanvas_menu subpage">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="canvas_open">
                                <a href="javascript:void(0)"><i class="ion-navicon-round"></i></a>
                            </div>
                            <div class="offcanvas_menu_wrapper">
                                <div class="canvas_close">
                                    <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                                </div>
                                
                                <div id="menu" class="text-left ">
                                    <div class="offcanvas_menu">
                                        <div class="canvas_open">
                                            <a href="javascript:void(0)"><i class="ion-navicon-round"></i></a>
                                        </div>
                                        <div class="offcanvas_menu_wrapper">
                                            <div class="canvas_close">
                                                <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                                            </div>
                                            <div id="menu" class="text-left ">
                                                <ul class="offcanvas_main_menu">
                                                    <?php 


                                                if($_SESSION['userdata']['guest_logged_in']==1)
                                                { 
                                                    $guest_user_id = $_SESSION['userdata']['guest_user_id'];
                                                    $guest_qry = $this->db->query("select * from guest_users where id='".$guest_user_id."'");
                                                    $guest_row = $guest_qry->row(); 
                                                    $location = $guest_row->location;
                                                }
                                                else if($_SESSION['userdata']['logged_in']==1)
                                                {
                                                    $user_id = $_SESSION['userdata']['user_id'];
                                                    $user_qry = $this->db->query("select * from users where id='".$user_id."'");
                                                    $user_row = $user_qry->row(); 
                                                    $location = $user_row->home_location;

                                                }

                                                ?>
                                                <li class="menu-item-has-children mr-5">
                                                    <a class="goglocation" href="#" data-sidebar-target="03" title="<?php if($location!=''){ echo $location; }else{ echo "Location Name"; }?>"><i class="fal fa-map-marker-alt"></i> <?php if($location!=''){ echo $location; }else{ echo "Location Name"; }?></a>
                                                </li>
                                                    <li class="menu-item-has-children active"><a href="<?php echo base_url(); ?>web">Home</a></li>
                                                    
                                                    <li class="menu-item-has-children">
                                                        <a href="#">Categories  </a>
                                                        <ul class="sub-menu">
                                                            <?php foreach($categories as $category){ ?>
                                                            <li><a href="<?php echo base_url(); ?>web/store_categories/<?php echo $category['seo_url']; ?>"><?php echo $category['title']; ?></a></li>
                                                            <?php } ?>
                                                        </ul>
                                                    </li>
                                                    <li class="menu-item-has-children"><a href="<?php echo base_url(); ?>web/about_us">About</a></li>
                                                    <li class="menu-item-has-children">
                                                        <a href="<?php echo base_url(); ?>web/contact_us"> Contact Us</a>
                                                    </li>

                                                    <!-- <li class="menu-item-has-children">
                                                    <a href="<?php echo base_url(); ?>web/changeLocation"> Change Location</a>
                                                </li> -->

                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--offcanvas menu area end-->
            
            <header>
                <div class="main_header sticky-header header_two">
                    <div class="container">
                        <div class="row align-items-center">
                            <div class="col-lg-2 col-md-4 offset-md-4 offset-lg-0 col-5 offset-3 col-sm-5">
                                <div class="logo">
                                    <a href="<?php echo base_url();?>web"><img src="<?php echo base_url();?>web_assets/img/logo-white.svg" alt=""></a>
                                </div>
                            </div>
                            <div class="col-lg-8">
                                <!--main menu start-->
                                <div class="main_menu menu_position">
                                    <nav>
                                        <ul>
                                            <li><a    href="<?php echo base_url(); ?>web">home</a></li>
                                          
                                            <li><a href="#">Categories <i class="fal fa-angle-down"></i></a>
                                            <ul class="sub_menu pages">
                                                <?php foreach($categories as $category){ ?>
                                                <li><a href="<?php echo base_url(); ?>web/store_categories/<?php echo $category['seo_url']; ?>"><?php echo $category['title']; ?></a></li>
                                                <?php } ?>
                                            </ul>
                                        </li>
                                        <li><a href="<?php echo base_url(); ?>web/about_us"> About us</a></li>
                                        <li><a href="<?php echo base_url(); ?>web/contact_us" > Contact Us</a></li>
                                        <!-- <li class="menu-item-has-children">
                                                    <a href="<?php echo base_url(); ?>web/changeLocation"> Change Location</a>
                                                </li> -->
                                        <li><div id="show_errormsg" class="alert-success"></div></li>
                                    </ul>
                                </nav>
                            </div>
                            <!--main menu end-->
                        </div>
                        <div class="col-lg-2 col-md-4 col-sm-4 col-4">
                            <div class="header_account_area">
                                <div class="header_account_list search_list">
                                    <?php if($search=='show'){ ?>
                                    <a href="javascript:void(0)"><span class="pe-7s-search"></span></a>
                                    <div class="dropdown_search">
                                       <form  enctype="multipart/form-data" method="post" accept-charset="utf-8" class="user" action="<?=site_url('web/search_shop_report');?>">
                                        <input type="hidden" name="shop_id" value="<?php echo $shop_id;?>">
                                        <input type="hidden" name="cat_url" value="<?php echo $cat_url;?>">
                                        <input type="hidden" name="subcat_url" value="<?php echo $subcat_url;?>">
                                            <input id="searchdata" name="searchdata" onkeyup="getshopdatasearch()" placeholder="Search entire store here ..." type="text">
                                            <button type="submit"><!-- <span class="pe-7s-search"></span> -->Search</button>
                                        </form>
                                        <ul class="serchcls" id="store_search_report">
                                        </ul>
                                    </div>
                                    <?php } ?>
                                </div>

                                <style type="text/css">
                                .serchcls{
                                padding-left: 10px;
                                }
                                .scrollsea{
                                    height: 300px;
                                overflow-y:scroll; 
                                }
                                .serchcls li{
                                width: 330px;
                                overflow: hidden;
                                text-overflow: ellipsis;
                                white-space: nowrap;
                                border-bottom: 1px solid #f4f4f4;
                                line-height: 30px;
                                }
                                </style>
                                <div class="header_account_list  mini_cart_wrapper">
                                    <a href="<?php echo base_url(); ?>web/checkout"><span class="pe-7s-shopbag"></span>
                                    <?php
                                    $session_id = $_SESSION['session_data']['session_id'];
                                    $user_id= $_SESSION['userdata']['user_id'];
                                    $cart_qry = $this->db->query("select * from cart where session_id='".$session_id."' and user_id='".$user_id."'");
                                    $cart_count = $cart_qry->num_rows();
                                    ?>
                                    <span class="item_count" id="cart_count"><?php echo $cart_count;?></span>
                                </a>
                                
                            </div>
                            <div class="language_currency header_account_list ">
                                <a href="#"> <span class="pe-7s-user"></span></a>
                                <ul class="dropdown_currency">
                                    <?php if($_SESSION['userdata']['user_id']!=''){ ?>
                                    <li><a href="<?php echo base_url(); ?>web/myaccount" ><i class="fal fa-user-tag fa-lg mr-1"></i>My Dashboard</a></li>
                                    <li><a href="<?php echo base_url(); ?>web/my_wishlist" ><i class="fal fa-heart fa-lg mr-1"></i>My Whishlist</a></li>
                                    <li><a href="<?php echo base_url(); ?>web/myprofile" ><i class="fal fa-user fa-lg mr-1"></i>My Profile</a></li>
                                    <li><a href="<?php echo base_url(); ?>web/logout" ><i class="fal fa-sign-out fa-lg mr-1"></i>Logout</a></li>
                                    <?php }else{ ?>
                                    <li><a href="#loginModal" data-toggle="modal">Login</a></li>
                                    <li><a href="#registerModal" data-toggle="modal">Register</a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--mini cart-->
        <!-- <div class="mini_cart" id="loadcart">
            <?php
            $qry = $this->db->query("select * from cart where session_id='".$session_id."' and user_id='".$user_id."'");
            $del_b = $qry->row();
            if($qry->num_rows()>0)
            {
            ?>
            <div class="cart_gallery">
                <div class="cart_close">
                    <div class="cart_text">
                        <h3>cart</h3>
                    </div>
                    <div class="mini_cart_close">
                        <a href="javascript:void(0)"><i class="ion-android-close"></i></a>
                    </div>
                </div>
                <div class="pro-cart">
                    <?php
                
                $shop = $this->db->query("select * from vendor_shop where id='".$del_b->vendor_id."'");
                $shopdat = $shop->row();
                $min_order_amount = $shopdat->min_order_amount;
                $result = $qry->result();
                
                $unitprice=0;
                $gst=0;
                foreach ($result as $value)
                {
                $pro = $this->db->query("select * from  product_images where variant_id='".$value->variant_id."'");
                $product = $pro->row();
                if($product->image!='')
                {
                $img = base_url()."uploads/products/".$product->image;
                }
                else
                {
                $img = base_url()."uploads/noproduct.png";
                }
                //$value->variant_id
                $var1 = $this->db->query("select * from link_variant where id='".$value->variant_id."'");
                $link = $var1->row();
                $pro1 = $this->db->query("select * from  products where id='".$link->product_id."'");
                $product1 = $pro1->row();
                $adm_qry = $this->db->query("select * from  admin_comissions where cat_id='".$product1->cat_id."' and shop_id='".$value->vendor_id."'");
                if( $adm_qry->num_rows()>0)
                {
                $adm_comm = $adm_qry->row();
                $p_gst = $adm_comm->gst;
                }
                else
                {
                $p_gst = '0';
                }
                $class_percentage = ($value->unit_price/100)*$p_gst;
                
                $variants1 = $var1->result();
                $att1=[];
                foreach ($variants1 as $value1)
                {
                
                $jsondata = $value1->jsondata;
                $values_ar=[];
                $json =json_decode($jsondata);
                foreach ($json as $value123)
                {
                $type = $this->db->query("select * from attributes_title where id='".$value123->attribute_type."'");
                $types = $type->row();
                
                $val = $this->db->query("select * from attributes_values where id='".$value123->attribute_value."'");
                $value1 = $val->row();
                $values_ar[]=array('id'=>$value1->id,'title'=>$types->title,'value'=>$value1->value);
                }
                
                }
                $unitprice = $value->unit_price+$unitprice;
                $gst = $class_percentage+$gst;
                ?>
                <div class="cart_item">
                    <div class="cart_img">
                        <a href="#"><img src="<?php echo $img; ?>" alt=""></a>
                    </div>
                    <div class="cart_info">
                        <a href="#"><?php echo $product1->name; ?></a>
                        <p><?php echo $value->quantity; ?> x <span> <i class="fal fa-rupee-sign"></i> <?php echo $value->price; ?> </span></p>
                    </div>
                    <div class="cart_remove">
                        <a onclick="deletecart(<?php echo $value->id; ?>)"><i class="ion-ios-close-outline"></i></a>
                    </div>
                </div>
                <?php }
                $grand_t =  $min_order_amount+$unitprice+$gst;
                ?>
                </div>
                
            </div>
            <div class="mini_cart_table">
                <div class="cart_table_border">
                    <div class="cart_total">
                        <span>Sub Total :</span>
                        <span class="price"><i class="fal fa-rupee-sign"></i> <?php echo $unitprice; ?></span>
                    </div>
                    <div class="cart_total mt-10">
                        <span>Shipping Charges : </span>
                        <span class="price"><i class="fal fa-rupee-sign"></i> <?php echo $min_order_amount; ?></span>
                    </div>
                    <hr>
                    <div class="cart_total mt-10">
                        <span>Total</span>
                        <span class="price"><i class="fal fa-rupee-sign"></i> <?php echo $grand_t; ?></span>
                    </div>
                </div>
            </div>
            <div class="mini_cart_footer">
                <div class="cart_button">
                    <a href="<?php echo base_url(); ?>web/checkout"><i class="fal fa-sign-in"></i> Checkout</a>
                </div>
            </div>
            <?php }else{ ?>
            <h3 style="text-align: center; color: red;">Cart Empty</h3>
            <?php } ?>
        </div> -->
        <!--mini cart end-->
    </header>
    <script type="text/javascript">
    function getshopdatasearch()
    {
    var keyword=$("#searchdata").val();
    var shop_id= '<?php echo $shop_id; ?>';
    $('.error').remove();
    var errr=0;
    $.ajax({
    url:"<?php echo base_url(); ?>web/storesearchdata",
    method:"POST",
    data:{keyword:keyword,shop_id:shop_id},
    success:function(data)
    {
        var element = document.getElementById("store_search_report");
        element.classList.add("scrollsea");

    $('#store_search_report').html(data);
    }
    });
    }
    function deletecart(cartid)
    {
    if(confirm("Are you sure you want to delete cart item")){
    $.ajax({
    url:"<?php echo base_url(); ?>web/deleteCartItem",
    method:"POST",
    data:{cartid:cartid},
    success:function(data)
    {
    var str = data;
    var res = str.split("@");
    //alert(JSON.stringify(res));
    if(res[1]=='success')
    {
    $('#show_errormsg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Cart Item deleted successfully</span>');
    $('#show_errormsg').focus();
    location.reload();
    return false;
    
    }
    else
    {
    $('#show_errormsg').html('<span class="error" style="color:red;font-size: 16px;margin-left: 18px; width:100%">Something went wrong , please try again</span>');
    $('#show_errormsg').focus();
    return false;
    }
    
    
    
    }
    });
    }
    }
    </script>