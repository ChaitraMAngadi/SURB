<!-- <ul class="dashboardlist d-none d-lg-block">
  <li <?php if ($page == 'my_account.php') { ?>class="active"<?php } ?>><a href="my_account.php"><i class="fal fa-user-tag"></i> My Account</a></li>
  <li <?php if ($page == 'my_orders.php') { ?>class="active"<?php } ?>><a href="my_orders.php"><i class="fal fa-list-ul"></i> My Orders</a></li>
  <li <?php if ($page == 'my_bids.php') { ?>class="active"<?php } ?>><a href="my_bids.php"><i class="fal fa-badge-percent"></i> My Bids</a></li>
  <li <?php if ($page == 'my_wishlist.php') { ?>class="active"<?php } ?>><a href="my_wishlist.php"><i class="fal fa-heart"></i> My Wishlist</a></li>
  <li <?php if ($page == 'my_addressbook.php') { ?>class="active"<?php } ?>><a href="my_addressbook.php"><i class="fal fa-address-book"></i> My Addressbook</a></li>
  <li <?php if ($page == 'my_profile.php') { ?>class="active"<?php } ?>><a href="my_profile.php"><i class="fal fa-user"></i> My Profile</a></li>
  <li <?php if ($page == 'become_a_vendor.php') { ?>class="active"<?php } ?>><a href="become_a_vendor.php"><i class="fal fa-store"></i> Become a Vendor</a></li>
  <li><a href="#"><i class="fal fa-sign-out"></i> Logout</a></li>
</ul> -->

<ul class="dashboardlist d-none d-lg-block">
  <li <?php if ($page == 'myaccount') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/myaccount"><i class="fal fa-user-tag"></i> My Account</a></li>
  <li <?php if ($page == 'myorders') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/my_orders"><i class="fal fa-list-ul"></i> My Orders</a></li>

  <?php $adm_qry = $this->db->query("select * from admin where bid_show_status=1");
                                         if($adm_qry->num_rows()>0){ ?>

   <li <?php if ($page == 'my_bids') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/my_bids"><i class="fal fa-badge-percent"></i> My Bids</a></li> 
 <?php } ?>
  <li <?php if ($page == 'mywishlist') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/my_wishlist"><i class="fal fa-heart"></i> My Wishlist</a></li>
  <li <?php if ($page == 'myaddressbook') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/my_addressbook"><i class="fal fa-address-book"></i> My Addressbook</a></li>
  <li <?php if ($page == 'myprofile') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/myprofile"><i class="fal fa-user"></i> My Profile</a></li>
  <li <?php if ($page == 'becomeavendor') { ?>class="active"<?php } ?>><a href="<?php echo base_url(); ?>web/become_a_vendor"><i class="fal fa-store"></i> Become a Vendor</a></li>
  <li><a href="<?php echo base_url(); ?>web/logout"><i class="fal fa-sign-out"></i> Logout</a></li>
</ul>