<?php  $this->load->view("web/includes/header_styles"); ?>

 <section class="slider_section slider_s_three">

        <div class="slider_area owl-carousel">
      
              <div class="single_slider">

                <img src="<?php echo base_url(); ?>/uploads/defaultslider.png" alt="" class="home-slider-img" width="100%">

            </div>


        </div>

    </section>



    <!-- <script src="<?php echo base_url();?>web_assets/js/jquery-1.11.0.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>web_assets/js/jquery.min.js"></script> -->

<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 -->
<script type="text/javascript">

 window.onload = function () {
  //alert("###");
  //window.location.reload()
  getCurrentLocation1();
}
  /*$( document ).ready(function() {

    getCurrentLocation1();
});*/
  function getCurrentLocation1()
    {
        var latitudeAndLongitude=document.getElementById("latitudeAndLongitude"),
    location={
        latitude:'',
        longitude:''
    };

    if (navigator.geolocation){
      navigator.geolocation.getCurrentPosition(showPosition);
    }
    else{
      console.log("Hiii");
      latitudeAndLongitude.innerHTML="Geolocation is not supported by this browser.";
    }

        function showPosition(position)
        { 
           console.log("Hiii");
            location.latitude=position.coords.latitude;
            location.longitude=position.coords.longitude;
            var geocoder = new google.maps.Geocoder();
            var latLng = new google.maps.LatLng(location.latitude, location.longitude);

         if (geocoder) {
          console.log("welcome");
            geocoder.geocode({ 'latLng': latLng}, function (results, status) {
               if (status == google.maps.GeocoderStatus.OK) {
                 saveLocation(results[0].formatted_address);
               }
               else {
                alert("Geocoding failed: " + status);
               }
            }); 
          }      
         }
    }



function saveLocation(selectedlocation)
{
    console.log(selectedlocation);
    $('.error').remove();
        var errr=0;

     
            $.ajax({
              url:"<?php echo base_url(); ?>web/getuserLocation",
              method:"POST",
              data:{selectedlocation:selectedlocation},
              success:function(data)
              {
                 var str = data;
              var res = str.split("@");
                  if(res[1]=='success')
                  {
                        var loc = '<?php echo $location; ?>';
                         // window.location.href = "<?php echo base_url(); ?>web";
                          window.location.href = "<?php echo base_url(); ?>"+loc;
                  }
                  else
                  {
                    alert("No shops in this location,Please change your location");
                  }
                      
                        
              
              }
             });
}

</script>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDiiWRvGqRwOJOVqYc8GEQhBuWj4mgSSTM&libraries=places&callback=getCurrentLocation1&sensor=false" async defer></script>
 
  <?php  $this->load->view("web/includes/footer"); ?>