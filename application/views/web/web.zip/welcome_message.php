<div style="text-align:center;margin-top:100px">
    <h1>Welcome, website is under construction </h1>


    <p>Sector6</p>

     <p>User App Playstore Link : <a href="" target="_blank" style="text-decoration: none;">Android App</a></p>
    
</div>
